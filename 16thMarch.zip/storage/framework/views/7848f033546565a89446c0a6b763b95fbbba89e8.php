
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Mail Setup'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<!-- quill css -->
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Mail Setup <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php
    if(!empty($ms)):
        $msId       = $ms->id;
        $host       = $ms->host;
        $port       = $ms->port;
        $userName   = $ms->userName;
        $password   = $ms->password;
        $encType    = $ms->encType;
        $formName   = $ms->formName;
        $formMail   = $ms->formEmail;
    else:
        $msId       = "";
        $host       = "";
        $port       = "";
        $userName   = "";
        $password   = "";
        $encType    = "";
        $formName   = "";
        $formMail   = "";
    endif;
?>
    <div class="row">
        <div class="col-12 col-md-8 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Email Setup <small class="text-success text-sm fw-bold">Mail Sending</small></h4>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>  
                    <p class="text-muted"> <code>Mail Driver</code> Setup</p>

                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-tabs-custom nav-success nav-justified mb-3" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#mail" role="tab" aria-selected="true">
                            <i class="ri-mail-fill"></i> Mail
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#smtp" role="tab" aria-selected="false">
                                <i class="ri-mail-send-fill"></i> SMTP
                            </a>
                        </li> 
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content text-muted">
                        <form action="<?php echo e(route('saveMail')); ?>" method="POST" class="tab-pane active row" id="mail" role="tabpanel">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($msId); ?>" name="msId">
                            <div class="col-7">
                                <div class="mb-3">
                                    <label for="formName" class="form-label">Mail Form Name</label>
                                    <input type="text" class="form-control" id="formName" placeholder="Enter mail form name" value="<?php echo e($formName); ?>" name="formName">
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="mb-3">
                                    <label for="formEmail" class="form-label">Mail Form Email</label>
                                    <input type="text" class="form-control" id="formEmail" placeholder="Enter mail form email" value="<?php echo e($formMail); ?>" name="formEmail">
                                </div>
                            </div>
                            <div class="col-7">
                                <div class="text-start mt-2 col-10">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                        <form action="<?php echo e(route('saveSmtp')); ?>" method="POST" class="tab-pane" id="smtp" role="tabpanel">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($msId); ?>" name="msId">
                            <div class="row">
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="mailHost" class="form-label">Mail Host</label>
                                        <input type="text" class="form-control" id="mailHost" placeholder="Enter mail host" value="<?php echo e($host); ?>" name="mailHost">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="mailPort" class="form-label">Mail Port</label>
                                        <input type="text" class="form-control" value="<?php echo e($port); ?>" id="mailPort" placeholder="Enter mail port" name="mailPort">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="mailUser" class="form-label">Mail Username</label>
                                        <input type="text" class="form-control" value="<?php echo e($userName); ?>" id="mailUser" placeholder="Enter username" name="mailUser">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="mailPass" class="form-label">Mail Password</label>
                                        <input type="password" class="form-control" id="mailPass" placeholder="Enter password" value="<?php echo e($password); ?>" name="mailPass">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="encType" class="form-label">Mail Encription</label>
                                        <select name="encType" id="encType" class="form-control">
                                            <?php if(!empty($encType)): ?>
                                            <option value="<?php echo e($encType); ?>"><?php echo e($encType); ?></option>
                                            <?php endif; ?>
                                            <option value="tls">tls</option>
                                            <option value="ssl">ssl</option>
                                            <option value="none">none</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="formName" class="form-label">Mail Form Name</label>
                                        <input type="text" class="form-control" id="formName" placeholder="Enter mail form name" value="<?php echo e($formName); ?>" name="formName">
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="mb-3">
                                        <label for="formEmail" class="form-label">Mail Form Email</label>
                                        <input type="text" class="form-control" id="formEmail" placeholder="Enter mail form email" value="<?php echo e($formMail); ?>" name="formEmail">
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="text-start mt-2 col-10">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- .card-->
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/listjs.init.js')); ?>"></script>

<!-- ckeditor -->
<script src="<?php echo e(asset('public/assets/libs/@ckeditor/@ckeditor.min.js')); ?>"></script>

<!-- quill js -->
<script src="<?php echo e(asset('public/assets/libs/quill/quill.min.js')); ?>"></script>

<!-- init js -->
<script src="<?php echo e(asset('public/assets/js/pages/form-editor.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/mailSettings.blade.php ENDPATH**/ ?>