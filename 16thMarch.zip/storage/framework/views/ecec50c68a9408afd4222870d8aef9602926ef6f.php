
<body>

<!-- <body data-layout="horizontal"> -->
<?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/layouts/body.blade.php ENDPATH**/ ?>