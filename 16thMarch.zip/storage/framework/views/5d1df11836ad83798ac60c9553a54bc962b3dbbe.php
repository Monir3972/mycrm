
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Server Default Page'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<!-- quill css -->
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Default Page <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-xl-11 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Default Pages <small class="text-success text-sm fw-bold">Frontend</small></h4>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>  
                    <p class="text-muted">Create <code>page</code> using this box</p>
                    <?php echo csrf_field(); ?>

                    <!-- Tab panes -->
                        <form action="<?php echo e(route('saveLayout')); ?>" method="POST" class="row mb-4">
                            <?php echo csrf_field(); ?>
                            <?php
                                $home = \App\Models\PageConfig::where(['pageName'=>'homepage'])->first();
                                if(!empty($home)):
                                    $pageTitle = $home->pageTitle;
                                else:
                                    $pageTitle = "";
                                endif;
                            ?>
                            <div class="col-12 col-md-7">
                                <h4>Homepages Pages Layout Settings</h4>
                                <input type="hidden" name="pageName" value="homepage">
                                <div class="my-3">
                                    <label for="pageTitle" class="form-label">Page Title</label>
                                    <input type="text" class="form-control" id="pageTitle" placeholder="Enter page title" value="<?php echo e($pageTitle); ?>" name="pageTitle">
                                </div>
                                <div class="mb-3">
                                    <label for="pageType" class="form-label">Layout</label>
                                    <select name="pageType" class="form-control">
                                        <?php if(!empty($home) && $home->pageType=="theme1"): ?>
                                            <option value="theme1">Theme 1</option>
                                        <?php elseif(!empty($home) && $home->pageType=="theme2"): ?>
                                            <option value="theme2">Theme 2</option>
                                        <?php endif; ?>
                                        <option value="theme1">Theme 1</option>
                                        <option value="theme2">Theme 2</option>
                                    </select>
                                </div>
                                <div class="text-start mt-4 col-10">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                        <form action="<?php echo e(route('saveLayout')); ?>" method="POST" class="row my-4">
                            <?php echo csrf_field(); ?>
                            <?php
                                $authPage = \App\Models\PageConfig::where(['pageName'=>'authpage'])->first();
                                if(!empty($authPage)):
                                    $authTitle = $authPage->pageTitle;
                                else:
                                    $authTitle = "";
                                endif;
                            ?>
                            <div class="col-12 col-md-7">
                                <h4>Login/Signup Pages Layout Settings</h4>
                                <input type="hidden" name="pageName" value="authpage">
                                <div class="my-3">
                                    <label for="pageTitle" class="form-label">Page Title</label>
                                    <input type="text" class="form-control" id="pageTitle" placeholder="Enter page title" value="<?php echo e($authTitle); ?>" name="pageTitle">
                                </div>
                                <div class="mb-3">
                                    <label for="pageType" class="form-label">Layout</label>
                                    <select name="pageType" class="form-control">
                                        <?php if(!empty($authPage) && $authPage->pageType=="Basic"): ?>
                                            <option value="Basic">Basic</option>
                                        <?php elseif(!empty($authPage) && $authPage->pageType=="Cover"): ?>
                                            <option value="Cover">Cover</option>
                                        <?php endif; ?>
                                        <option value="Basic">Basic</option>
                                        <option value="Cover">Cover</option>
                                    </select>
                                </div>
                                <div class="text-start mt-4 col-10">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                </div>
            </div> <!-- .card-->
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/listjs.init.js')); ?>"></script>

<!-- ckeditor -->
<script src="<?php echo e(asset('public/assets/libs/@ckeditor/@ckeditor.min.js')); ?>"></script>

<!-- quill js -->
<script src="<?php echo e(asset('public/assets/libs/quill/quill.min.js')); ?>"></script>

<!-- init js -->
<script src="<?php echo e(asset('public/assets/js/pages/form-editor.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/layoutPage.blade.php ENDPATH**/ ?>