
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Manage Product'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Product Management <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <?php if(Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo Session::get('success'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(Session::get('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo Session::get('error'); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>  
        <div class="col-xl-3 mx-auto">
            <label class="form-label"><span class="ri-filter-line"></span> Filter Results</label>
            <form class="form-control" action="">
                <div class="mb-3">
                    <label for="typeOf" class="form-label">Type of</label>
                    <select class="form-control" id="typeOf">
                        <option value="All">All</option>
                        <option value="Month">Monthly</option>
                        <option value="Annual">Annual</option>
                    </select>
                </div>
                <div class="mb-2">
                    <span class="text-start"><button type="submit" class="btn btn-success">Filter Table</button></span>
                    <span class="text-end"><button type="reset" class="btn btn-primary">Reset</button></span>
                </div>
            </form>
        </div>
        <div class="col-xl-9 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Product <span class="text-info"><?php echo e(count($product)); ?></span> <small class="text-muted text-sm">Total products</small></h4>
                    <div class="flex-shrink-0">
                        <a href="<?php echo e(route('newProduct')); ?>" class="btn btn-info btn-sm">
                            <i class="ri-add-box-line align-middle"></i> Add Product
                        </a>
                    </div>
                </div><!-- end card header -->

                <div class="card-body">
                    <div class="table-responsive table-card">
                        <table class="table table-borderless table-hover table-nowrap align-middle mb-0">
                            <thead class="table-light">
                                <tr class="text-muted">
                                    <th scope="col">#</th>
                                    <th scope="col">Product</th>
                                    <th scope="col">Annual Price</th>
                                    <th scope="col">Monthly Price</th>
                                    <th scope="col">Employee</th>
                                    <th scope="col">Storage</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if(count($product)>0): ?>
                                <?php
                                    $x=1;
                                ?>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($x); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0 me-2">
                                                <img src="<?php echo e(asset('/')); ?>public/assets/images/product/<?php echo e($pro->media); ?>" alt="<?php echo e($pro->productName); ?>" class="avatar-xs rounded-circle">
                                            </div>
                                            <div class="flex-grow-1"><?php echo e($pro->productName); ?></div>
                                        </div>
                                    </td>
                                    <td><?php echo e($pro->annualPrice); ?></td>
                                    <td><?php echo e($pro->monthlyPrice); ?></td>
                                    <td><?php echo e($pro->employee); ?></td>
                                    <td><?php echo e($pro->storage); ?></td>
                                    <td>
                                        <?php if($pro->status=="Enable"): ?>
                                        <span class="text-success">Active</span>
                                        <?php else: ?>
                                        <span class="text-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('editProduct',['id'=>$pro->id])); ?>" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                        <a href="<?php echo e(route('delProduct',['id'=>$pro->id])); ?>" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                    </td>
                                </tr>
                                <?php
                                    $x++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td>1</td>
                                    <td>VITP</td>
                                    <td>vitp@gmail.com</td>
                                    <td>Elite</td>
                                    <td>Elite</td>
                                    <td>$520.03</td>
                                    <td><span class="text-success">Active</span></td>
                                    <td>
                                        <a href="#" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                        <a href="#" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>CIP</td>
                                    <td>cip@gmail.com</td>
                                    <td>Pro</td>
                                    <td>Elite</td>
                                    <td>$318.83</td>
                                    <td><span class="text-danger">Block</span></td>
                                    <td>
                                        <a href="#" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                        <a href="#" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody><!-- end tbody -->
                        </table><!-- end table -->
                    </div><!-- end table responsive -->
                </div>
            </div> <!-- .card-->
            
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/productList.blade.php ENDPATH**/ ?>