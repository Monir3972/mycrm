
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('FAQ List'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<!-- quill css -->
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> FAQ List <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-xl-11 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Admin FAQ <small class="text-success text-sm fw-bold">Frontend</small></h4>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>  
                    <p class="text-muted">Create <code>FAQ</code> using this box</p>
                    <?php echo csrf_field(); ?>
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-tabs-custom nav-success nav-justified mb-3" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#newFaq" role="tab" aria-selected="true">
                            <i class="las la-file"></i> New Question
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#faqList" role="tab" aria-selected="false">
                                <i class="las la-list"></i> FAQ List
                            </a>
                        </li> 
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content text-muted">
                        <div class="tab-pane" id="faqList" role="tabpanel">
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <div class="table-responsive mt-3 mb-1">
                                        <table class="table align-middle" id="customerTable">
                                            <thead class="table-light">
                                                <th>Question</th>
                                                <th>Action</th>
                                            </thead>
                                            <tbody>
                                                <?php if(count($faq)>0): ?>
                                                <?php
                                                    $x=1;
                                                ?>
                                                <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($f->question); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('editFaq',['id'=>$f->id])); ?>" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                                        <a href="<?php echo e(route('delFaq',['id'=>$f->id])); ?>" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                                    </td>
                                                </tr>
                                                <?php
                                                    $x=1;
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <tr>
                                                    <td>What is MyCRM?</td>
                                                    <td>
                                                        <a href="#" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                                        <a href="#" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('saveFaq')); ?>" method="POST" class="tab-pane active row" id="newFaq" role="tabpanel">
                            <?php echo csrf_field(); ?>
                            <div class="col-10 mx-auto">
                                <div class="mb-3">
                                    <label for="question" class="form-label">Question</label>
                                    <input type="text" class="form-control" id="question" placeholder="Enter FAQ question" name="question">
                                </div>
                                <div class="mb-3">
                                    <label for="answer" class="form-label">Answer</label>
                                    <textarea id="answer" name="answer" class="ckeditor-classic"></textarea>
                                </div>
                                <div class="text-start mt-4 col-10">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- .card-->
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/listjs.init.js')); ?>"></script>

<!-- ckeditor -->
<script src="<?php echo e(asset('public/assets/libs/@ckeditor/@ckeditor.min.js')); ?>"></script>

<!-- quill js -->
<script src="<?php echo e(asset('public/assets/libs/quill/quill.min.js')); ?>"></script>

<!-- init js -->
<script src="<?php echo e(asset('public/assets/js/pages/form-editor.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/faqList.blade.php ENDPATH**/ ?>