
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Update Profile'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Update Profile <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-12 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Details Update</h4>
                </div><!-- end card header -->

                <div class="card-body"><!-- Primary Alert -->
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty($profile)): ?>
                    <form action="<?php echo e(route('saveAdminProfile')); ?>" class="form" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="profileId" value="<?php echo e($profile->id); ?>">
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="profileName" class="form-label">Admin Name</label>
                                <input type="text" class="form-control" name="profileName" id="profileName" value="<?php echo e($profile->name); ?>" placeholder="Enter admin name">
                            </div>
                            <div class="col-6 mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" value="<?php echo e($profile->email); ?>" name="email" id="email" placeholder="Enter admin email" readonly>
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <form action="<?php echo e(route('updateAdminAvatar')); ?>" class="form mt-4" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="profileId" value="<?php echo e($profile->id); ?>">
                        <input type="hidden" name="profileName" value="<?php echo e($profile->name); ?>">
                        <div class="row">
                            <div class="col-12 mb-3">
                                <h4 class="card-title mb-2 flex-grow-1">Avatar</h4>
                            </div>
                            <div class="col-6 col-md-2">
                                <img class="img-fluid rounded" src="<?php echo e(asset('/public/assets/images/admin/'.$profile->avatar)); ?>" alt="<?php echo e($profile->name); ?>">
                            </div>
                        </div>
                            
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="avatar" class="form-label">New Avatar</label>
                                <input type="file" name="avatar" class="form-control" id="avatar" required>
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <form action="<?php echo e(route('updateCompPass')); ?>" class="form mt-4" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="profileId" value="<?php echo e($profile->id); ?>">
                        <div class="row">
                            <div class="col-12 mb-3">
                                <h4 class="card-title mb-2 flex-grow-1">Credentials update</h4>
                            </div>
                            <div class="col-7 mb-3">
                                <label for="password" class="form-label">Old Password</label>
                                <input type="password" class="form-control" name="oldPass" id="password" placeholder="Enter your old password" required>
                            </div>
                            <div class="col-7 mb-3">
                                <label for="password" class="form-label">New Password</label>
                                <input type="password" class="form-control" name="newPass" id="password" placeholder="Enter a new password" required>
                            </div>
                            <div class="col-7 mb-3">
                                <label for="password" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" name="confirmPass" id="password" placeholder="Confirm new password" required>
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <?php else: ?>
                        <div class="alert alert-info">Sorry! No data found</div>
                    <?php endif; ?>;
                </div>  
            </div> <!-- .card-->
            
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/profileSettings.blade.php ENDPATH**/ ?>