/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!***********************************************!*\
  !*** ./resources/js/pages/task-creat.init.js ***!
  \***********************************************/
/*
Template Name: Borex - Admin & Dashboard Template
Author: Themesbrand
Website: https://Themesbrand.com/
Contact: Themesbrand@gmail.com
File:  Task Creat Js File
*/
// flatpickr
flatpickr('#datepicker-basic');
flatpickr('#datepicker-datetime-start', {
  enableTime: true,
  dateFormat: "m-d-Y H:i"
});
flatpickr('#datepicker-datetime-end', {
  enableTime: true,
  dateFormat: "m-d-Y H:i"
});
/******/ })()
;