<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ForgotPassPageController extends Controller
{
    //
}
