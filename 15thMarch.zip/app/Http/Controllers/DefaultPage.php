<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DefaultPage extends Controller
{
    //
}
