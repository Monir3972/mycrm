<?php

namespace App\Http\Controllers;

use App\Models\AdminPanel;
use App\Models\PageConfig;
use App\Models\GeneralSettings;
use App\Models\Pricing;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class FrontendController extends Controller
{
    public function homepage(){
        $details = GeneralSettings::orderBy('id','DESC')->first();
        $layout   = PageConfig::where(['pageName'=>'homepage'])->first();
        if(!empty($layout)):
            if($layout->pageType=="theme1"):
                return view('frontend.basicHome',['details'=>$details,'layout'=>$layout]);
            else:
                return view('frontend.advanceHome',['details'=>$details,'layout'=>$layout]);
            endif;
        else:
            return view('frontend.basicHome',['details'=>$details]);
        endif;
    }

    public function adminLogin(){
        $layout   = PageConfig::where(['pageName'=>'authpage'])->first();
        if(!empty($layout)):
            if($layout->pageType=="Basic"):
                return view('frontend.basicSignin',['layout'=>$layout]);
            else:
                return view('frontend.coverSignin',['layout'=>$layout]);
            endif;
        else:
            return view('frontend.coverSignin');
        endif;
    }

    public function loginConfirm(Request $requ){
        $admin = AdminPanel::where(['email'=>$requ->username])->first();
        if(!empty($admin)):
            $hashpass  = $admin->loginPass;
            $sessionid  = $admin->id;
            $authuser = Hash::check($requ->password,$hashpass);
            if($authuser):
                session_start();
                Session::regenerate();
                Session::put('adminAuth',$sessionid);
                Session::get('adminAuth');
                $_SESSION['adminAuth']   = $sessionid;
                return redirect(route('superAdmin'));
            else:
                return redirect(route('adminLogin'))->with('error','Sorry! Wrong password provide');
            endif;
        endif;
    }

    public function signupConfirm(Request $requ){
        $admin = AdminPanel::where(['email'=>$requ->username])->first();
        if(!empty($admin)):
            return back()->with('error','Sorry! Admin account already exist');
        else:
            $admin = new AdminPanel();
            $hashpass  = Hash::make($requ->password);
            $admin->name        = $requ->adminName;
            $admin->email       = $requ->username;
            $admin->loginPass   = $hashpass;
            $admin->plainPass   = $requ->password;
            if($admin->save()):
                return back()->with('success','Congrats! Admin profile created successfully');
            else:
                return back()->with('error','Sorry! Wrong password provide');
            endif;
        endif;
    }

    public function pricing(){
        $pricing =  Pricing::all();
        return view('frontend.pricing',['pricing'=>$pricing]);
    }
}
