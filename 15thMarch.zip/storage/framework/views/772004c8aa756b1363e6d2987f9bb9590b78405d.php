<script src="<?php echo e(asset('public/assets/libs/bootstrap/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/node-waves/node-waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/feather-icons/feather-icons.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/lord-icon-2.1.0.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/plugins.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/layouts/vendor-scripts.blade.php ENDPATH**/ ?>