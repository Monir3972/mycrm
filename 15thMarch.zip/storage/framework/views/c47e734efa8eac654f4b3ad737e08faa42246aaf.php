
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('General Settings'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<!-- quill css -->
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> General Settings <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php
    if(!empty($gs)):
        $gsId           = $gs->id;
        $companyName    = $gs->companyName;
        $email          = $gs->email;
        $phone          = $gs->phone;
        $website        = $gs->website;
        $currency       = $gs->currency;
        $language       = $gs->language;
        $timezone       = $gs->timezone;
        $generalLogo    = $gs->randLogo;
        $favicon        = $gs->favicon;
        $frontLogo      = $gs->frontLogo;
        $address        = $gs->address;
    else:
        $gsId           = "";
        $companyName    = "";
        $email          = "";
        $phone          = "";
        $website        = "";
        $currency       = "";
        $language       = "";
        $timezone       = "";
        $generalLogo    = "";
        $favicon        = "";
        $frontLogo      = "";
        $address        = "";
    endif;
?>
    <div class="row">
        <div class="col-xl-11 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Genereal Settings <small class="text-success text-sm fw-bold">Frontend</small></h4>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>  
                    <p class="text-muted">Manage <code>General Settings</code> using this box</p>
                    <?php echo csrf_field(); ?>

                    <form action="<?php echo e(route('saveGeneralSettings')); ?>" method="POST" class="row" id="newFaq" role="tabpanel">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="gsId" value="<?php echo e($gsId); ?>">
                        <div class="col-md-6 mx-auto">
                            <div class="mb-3">
                                <label for="companyName" class="form-label">Company Name</label>
                                <input type="text" class="form-control" id="question" placeholder="Enter company name" value="<?php echo e($companyName); ?>" name="companyName">
                            </div>
                        </div>
                        <div class="col-md-6 mx-auto">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="text" class="form-control" id="question" placeholder="Enter email of the company" value="<?php echo e($email); ?>" name="email">
                            </div>
                        </div>
                        <div class="col-md-6 mx-auto">
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="question" placeholder="Enter phone number of the company" value="<?php echo e($phone); ?>" name="phone">
                            </div>
                        </div>
                        <div class="col-md-6 mx-auto">
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea class="form-control" id="question" placeholder="Enter company location address" name="address"> <?php echo e($address); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6 mx-auto">
                            <div class="mb-3">
                                <label for="language" class="form-label">Language</label>
                                <select class="form-control" name="language">
                                    <?php
                                        $languageList = \App\Models\Language::all();
                                        $singleLang = \App\Models\Language::find($language);
                                    ?>
                                    <?php if(!empty($singleLang)>0): ?>
                                        <option value="<?php echo e($singleLang->id); ?>"><?php echo e($singleLang->language); ?></option>
                                    <?php endif; ?>
                                    <?php if(count($languageList)>0): ?>
                                        <?php $__currentLoopData = $languageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lang->id); ?>"><?php echo e($lang->language); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="0">Bangla</option>
                                        <option value="0">English</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 mx-auto">
                            <div class="mb-3">
                                <label for="currency" class="form-label">Currency</label>
                                <select class="form-control" name="currency">
                                    <?php
                                        $currencyList = \App\Models\Currency::all();
                                        $singCurr = \App\Models\Currency::find($currency);
                                    ?>
                                    <?php if(!empty($singCurr)>0): ?>
                                        <option value="<?php echo e($singCurr->id); ?>"><?php echo e($singCurr->currency); ?></option>
                                    <?php endif; ?>
                                    <?php if(count($currencyList)>0): ?>
                                        <?php $__currentLoopData = $currencyList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($curr->id); ?>"><?php echo e($curr->currency); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="0">USD</option>
                                        <option value="0">GBP</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="timeZone" class="form-label">Time Zone</label>
                                <select class="form-control" name="timeZone" id="timeZone">
                                    <?php if(!empty($timezone)): ?>
                                    <option value="<?php echo e($timezone); ?>"><?php echo e($timezone); ?></option>
                                    <?php endif; ?>
                                    <option value="UTC+3">UTC+3</option>
                                    <option value="UTC+2">UTC+2</option>
                                    <option value="UTC+1">UTC+1</option>
                                    <option value="UTC+0">UTC+0</option>
                                    <option value="UTC">UTC</option>
                                    <option value="UTC-0">UTC-0</option>
                                    <option value="UTC-1">UTC-1</option>
                                    <option value="UTC-2">UTC-2</option>
                                    <option value="UTC-3">UTC-3</option>
                                </select>
                            </div>
                        </div>
                        <div class="text-start mt-4 col-10">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                    <!-- Update general logo of the site -->
                    <form action="<?php echo e(route('updateGenLogo')); ?>" class="form mt-4" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="gsId" value="<?php echo e($gsId); ?>">
                        <input type="hidden" name="companyName" value="<?php echo e($companyName); ?>">
                        <div class="row">
                            <div class="col-12 my-4">
                                <h4 class="card-title mb-2 flex-grow-1">General Logo Update</h4>
                            </div>
                            <div class="col-4 my-3">
                                <img class="img-fluid" src="<?php if(!empty($generalLogo)): ?> <?php echo e(asset('/public/assets/images/logo/'.$generalLogo)); ?> <?php else: ?> <?php echo e(asset('/public/assets/images/logo-dark.png')); ?> <?php endif; ?>" alt="General Logo">
                            </div>
                        </div>
                            
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="randLogo" class="form-label">New Logo</label>
                                <input type="file" name="randLogo" class="form-control" id="randLogo" required>
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <!-- Update frontend logo of the site -->
                    <form action="<?php echo e(route('updateFrontLogo')); ?>" class="form mt-4" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="gsId" value="<?php echo e($gsId); ?>">
                        <input type="hidden" name="companyName" value="<?php echo e($companyName); ?>">
                        <div class="row">
                            <div class="col-12 mb-4">
                                <h4 class="card-title mb-2 flex-grow-1">Frontend Logo</h4>
                            </div>
                            <div class="col-4 mb-4">
                                <img class="img-fluid" src="<?php if(!empty($frontLogo)): ?> <?php echo e(asset('/public/assets/images/logo/'.$frontLogo)); ?> <?php else: ?> <?php echo e(asset('/public/assets/images/logo-dark.png')); ?> <?php endif; ?>" alt="Frontend Logo">
                            </div>
                        </div>
                            
                        <div class="row">
                            <div class="col-6 mb-4">
                                <label for="frontLogo" class="form-label">New Logo</label>
                                <input type="file" name="frontLogo" class="form-control" id="frontLogo" required>
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <!-- Update favicon of the site -->
                    <form action="<?php echo e(route('updateFavicon')); ?>" class="form mt-4" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="gsId" value="<?php echo e($gsId); ?>">
                        <input type="hidden" name="companyName" value="<?php echo e($companyName); ?>">
                        <div class="row">
                            <div class="col-12 mb-3">
                                <h4 class="card-title mb-4 flex-grow-1">Favicon Update</h4>
                            </div>
                            <div class="col-md-2 col-4 mb-4">
                                <img class="img-fluid" src="<?php if(!empty($favicon)): ?> <?php echo e(asset('/public/assets/images/logo/'.$favicon)); ?> <?php else: ?> <?php echo e(asset('/public/assets/images/logo-sm.png')); ?> <?php endif; ?>" alt="Frontend Logo">
                            </div>
                        </div>
                            
                        <div class="row">
                            <div class="col-6 mb-4">
                                <label for="favicon" class="form-label">New Logo</label>
                                <input type="file" name="favicon" class="form-control" id="favicon" required>
                            </div>
                            <div class="text-start">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div> <!-- .card-->
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/listjs.init.js')); ?>"></script>

<!-- ckeditor -->
<script src="<?php echo e(asset('public/assets/libs/@ckeditor/@ckeditor.min.js')); ?>"></script>

<!-- quill js -->
<script src="<?php echo e(asset('public/assets/libs/quill/quill.min.js')); ?>"></script>

<!-- init js -->
<script src="<?php echo e(asset('public/assets/js/pages/form-editor.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/generalSettings.blade.php ENDPATH**/ ?>