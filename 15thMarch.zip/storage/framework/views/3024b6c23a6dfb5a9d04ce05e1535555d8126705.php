<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Update Currency'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Update Currency <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-xl-8 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Update Currency</h4>
                    <div class="flex-shrink-0">
                        <button type="button" class="btn btn-soft-info btn-sm">
                            <i class="ri-file-list-3-line align-middle"></i> Update Data
                        </button>
                    </div>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?> 
                    <?php if(!empty($currency)): ?>
                    <form action="<?php echo e(route('updateCurrency')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="currId" value="<?php echo e($currency->id); ?>">
                        <div class="mb-3">
                            <label for="currencyName" class="form-label">Currency Name</label>
                            <input type="text" class="form-control" name="currencyName" id="currencyName" placeholder="Enter currency name" value="<?php echo e($currency->currency); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="shortName" class="form-label">Short Name</label>
                            <input type="text" class="form-control" id="shortName" placeholder="Enter language short name" name="shortName" value="<?php echo e($currency->shortCode); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="symble" class="form-label">Symble</label>
                            <input type="text" class="form-control" id="symble" placeholder="Enter currency symble" name="symble" value="<?php echo e($currency->symble); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="currStatus" class="form-label">Status</label>
                            <select class="form-control" name="currStatus" id="currStatus">
                                <option value="<?php echo e($currency->status); ?>"><?php echo e($currency->status); ?></option>
                                <option value="Enable">Enable</option>
                                <option value="Disable">Disable</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="rtl" class="form-label">RTL</label>
                            <select  class="form-control" name="rtl" id="rtl">
                                <option value="<?php echo e($currency->rtl); ?>"><?php echo e($currency->rtl); ?></option>
                                <option value="On">On</option>
                                <option value="Off">Off</option>
                            </select>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Update Data</button>
                        </div>
                    </form>
                    <?php else: ?>
                    <div class="alert alert-danger">Sorry! No record found</div>
                    <?php endif; ?>
                </div>
            </div> <!-- .card-->
            <div class="mb-4">
                <a href="<?php echo e(route('currencyList')); ?>" class="btn btn-success btn-sm">Manage Currency</a> 
            </div>
            
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/editCurrency.blade.php ENDPATH**/ ?>