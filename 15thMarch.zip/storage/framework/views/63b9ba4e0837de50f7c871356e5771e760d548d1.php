
<?php $__env->startSection('frontTitle'); ?> Pricing <?php $__env->stopSection(); ?>
<?php $__env->startSection('pageHeadline'); ?> Pricing <?php $__env->stopSection(); ?>
<?php $__env->startSection('pageDetails'); ?> Lorem ipsom dollar site is common text for the design industry <?php $__env->stopSection(); ?>
<?php $__env->startSection('pageHeader'); ?>
    <?php echo $__env->make('frontend.pageHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontcontent'); ?>
    <!-- ./Pricing Table - Simple Columns -->
    <section class="section">
        <div class="container">
            <div class="row">
                <?php if(count($pricing)>0): ?>
                <?php
                    $x = 1;
                ?>
                <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mt-5 col-12">
                    <div class="card text-center">
                        <div class="pricing card-header p-5 d-flex align-items-center flex-column <?php if($x%2==0): ?> bg-primary text-contrast <?php else: ?> bg-light text-dark <?php endif; ?>">
                            <h4 class="bold <?php if($x%2==0): ?> text-contrast <?php else: ?> text-dark <?php endif; ?>"><?php echo e($price->productName); ?></h4>

                            <div class="pricing-value">
                                <span class="price <?php if($x%2==0): ?> text-contrast <?php else: ?> text-dark <?php endif; ?>">
                                    <?php echo e($price->monthlyPrice); ?>

                                </span>
                            </div>

                            <p><?php echo e($price->details); ?></p>
                        </div>

                        <ul class="list-group list-group-flush">
                            <?php
                                $mod1 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Clients'])->first();
                                $mod2 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Employees'])->first();
                                $mod3 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Projects'])->first();
                                $mod4 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Attandence'])->first();
                                $mod5 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Tasks'])->first();
                                $mod6 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Estimate'])->first();
                                $mod7 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Invoice'])->first();
                                $mod8 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Payments'])->first();
                                $mod9 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Time Logs'])->first();
                                $mod10 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Tickets'])->first();
                                $mod11 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Events'])->first();
                                $mod12 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Messages'])->first();
                                $mod13 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Notices'])->first();
                                $mod14 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Leaves'])->first();
                                $mod15 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Leads'])->first();
                                $mod16 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Holidays'])->first();
                                $mod17 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Products'])->first();
                                $mod18 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Expenses'])->first();
                                $mod19 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Contracts'])->first();
                                $mod20 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Reports'])->first();
                                $mod21 = \App\Models\PackageModule::where(['packId'=>$price->id,'moduleName'=>'Ticket Support'])->first();
                            ?>
                            <li class="list-group-item"><b>Storage</b> <?php echo e($price->storage); ?></li>
                            <li class="list-group-item"><b>Employee Facility</b> <?php echo e($price->employee); ?></li>
                            <li class="list-group-item"> <?php if(!empty($mod1)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Clients</li>
                            <li class="list-group-item"> <?php if(!empty($mod2)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Employees</li>
                            <li class="list-group-item"> <?php if(!empty($mod3)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Projects</li>
                            <li class="list-group-item"> <?php if(!empty($mod4)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Attandence</li>
                            <li class="list-group-item"> <?php if(!empty($mod5)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Tasks</li>
                            <li class="list-group-item"> <?php if(!empty($mod6)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Estimate</li>
                            <li class="list-group-item"> <?php if(!empty($mod7)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Invoice</li>
                            <li class="list-group-item"> <?php if(!empty($mod8)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Payments</li>
                            <li class="list-group-item"> <?php if(!empty($mod9)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Time Logs</li>
                            <li class="list-group-item"> <?php if(!empty($mod10)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Tickets</li>
                            <li class="list-group-item"> <?php if(!empty($mod11)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Events</li>
                            <li class="list-group-item"> <?php if(!empty($mod12)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Messages</li>
                            <li class="list-group-item"> <?php if(!empty($mod13)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Notices</li>
                            <li class="list-group-item"> <?php if(!empty($mod14)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Leaves</li>
                            <li class="list-group-item"> <?php if(!empty($mod15)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Leads</li>
                            <li class="list-group-item"> <?php if(!empty($mod16)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Holidays</li>
                            <li class="list-group-item"> <?php if(!empty($mod17)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Products</li>
                            <li class="list-group-item"> <?php if(!empty($mod18)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Expenses</li>
                            <li class="list-group-item"> <?php if(!empty($mod19)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Contracts</li>
                            <li class="list-group-item"> <?php if(!empty($mod20)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Reports</li>
                            <li class="list-group-item"> <?php if(!empty($mod21)): ?> <i class="fas fa-check-square text-success"></i> <?php else: ?> <i class="fas fa-times text-danger"></i> <?php endif; ?> Ticket Support</li>
                        </ul>

                        <div class="card-body">
                            <a href="javascript:;" class="btn btn-rounded btn-outline-primary"> Buy now <i class="fa fa-long-arrow-alt-right ms-3"></i> </a>
                        </div>
                    </div>
                </div>
                <?php
                    $x++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="col-md-4 mt-5 col-12">
                    <div class="card text-center">
                        <div class="pricing card-header p-5 d-flex align-items-center flex-column bg-light">
                            <h4 class="bold">Personal</h4>

                            <div class="pricing-value">
                                <span class="price text-dark">
                                    0.99
                                </span>
                            </div>

                            <p>For individuals &amp; small business.</p>
                        </div>

                        <ul class="list-group list-group-flush">
                            <li class="list-group-item strike-through">Cras justo odio</li>
                            <li class="list-group-item strike-through">Dapibus ac facilisis in</li>
                            <li class="list-group-item strike-through">Morbi leo risus</li>
                            <li class="list-group-item">Porta ac consectetur ac</li>
                            <li class="list-group-item">Vestibulum at eros</li>
                        </ul>

                        <div class="card-body">
                            <a href="javascript:;" class="btn btn-rounded btn-outline-primary"> Buy now <i class="fa fa-long-arrow-alt-right ms-3"></i> </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5 col-12">
                    <div class="card text-center">
                        <div class="pricing card-header p-5 d-flex align-items-center flex-column bg-primary text-contrast">
                            <h4 class="bold text-contrast">Business</h4>

                            <div class="pricing-value">
                                <span class="price text-contrast">
                                    19.99
                                </span>
                            </div>

                            <p>For growing companies.</p>
                        </div>

                        <ul class="list-group list-group-flush">
                            <li class="list-group-item strike-through">Cras justo odio</li>
                            <li class="list-group-item strike-through">Dapibus ac facilisis in</li>
                            <li class="list-group-item">Morbi leo risus</li>
                            <li class="list-group-item">Porta ac consectetur ac</li>
                            <li class="list-group-item">Vestibulum at eros</li>
                        </ul>

                        <div class="card-body">
                            <a href="javascript:;" class="btn btn-rounded btn-primary"> Buy now <i class="fa fa-long-arrow-alt-right ms-3"></i> </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5 col-12">
                    <div class="card text-center">
                        <div class="pricing card-header p-5 d-flex align-items-center flex-column bg-light">
                            <h4 class="bold">Enterprise</h4>

                            <div class="pricing-value">
                                <span class="price text-dark">
                                    99.99
                                </span>
                            </div>

                            <p>For enterprise teams.</p>
                        </div>

                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Cras justo odio</li>
                            <li class="list-group-item">Dapibus ac facilisis in</li>
                            <li class="list-group-item">Morbi leo risus</li>
                            <li class="list-group-item">Porta ac consectetur ac</li>
                            <li class="list-group-item">Vestibulum at eros</li>
                        </ul>

                        <div class="card-body">
                            <a href="javascript:;" class="btn btn-rounded btn-outline-primary"> Buy now <i class="fa fa-long-arrow-alt-right ms-3"></i> </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- ./Plans features -->
    <section class="section">
        <div class="container">
            <div class="section-heading text-center">
                <h2 class="bold">All our plans include</h2>
                <p class="lead text-secondary">Get access to a ton of features out of the box</p>
            </div>

            <div class="row gap-y text-center">
                <div class="col-md-4">
                    <i data-feather="headphones" width="36" height="36" class="stroke-info me-2 m-0"></i>
                    <h5 class="bold my-3">First class support</h5>
                    <p class="my-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque beatae dicta dolores hic porro quam voluptatibus.</p>
                </div>
                <div class="col-md-4">
                    <i data-feather="box" width="36" height="36" class="stroke-info me-2 m-0"></i>
                    <h5 class="bold my-3">Code snippets</h5>
                    <p class="my-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque beatae dicta dolores hic porro quam voluptatibus.</p>
                </div>
                <div class="col-md-4">
                    <i data-feather="headphones" width="36" height="36" class="stroke-info me-2 m-0"></i>
                    <h5 class="bold my-3">Full documentation</h5>
                    <p class="my-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque beatae dicta dolores hic porro quam voluptatibus.</p>
                </div>
                <div class="col-md-4">
                    <i data-feather="lock" width="36" height="36" class="stroke-info me-2 m-0"></i>
                    <h5 class="bold my-3">Total control of your code</h5>
                    <p class="my-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque beatae dicta dolores hic porro quam voluptatibus.</p>
                </div>
                <div class="col-md-4">
                    <i data-feather="airplay" width="36" height="36" class="stroke-info me-2 m-0"></i>
                    <h5 class="bold my-3">Responsive design</h5>
                    <p class="my-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque beatae dicta dolores hic porro quam voluptatibus.</p>
                </div>
                <div class="col-md-4">
                    <i data-feather="monitor" width="36" height="36" class="stroke-info me-2 m-0"></i>
                    <h5 class="bold my-3">Browser support</h5>
                    <p class="my-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci atque beatae dicta dolores hic porro quam voluptatibus.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ./FAQs -->
    <section class="section bg-light edge bottom-right border-top">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h2>Do you have <span class="bold">questions?</span></h2>
                    <p class="lead">Not sure how this template can help you? Wonder why you need to buy our theme?</p>
                    <p class="text-muted">Here are the answers to some of the most common questions we hear from our appreciated customers</p>
                </div>

                <div class="col-md-8">
                    <div class="accordion accordion-clean" id="faqs-accordion">
                        <div class="card mb-3">
                            <div class="card-header">
                                <a href="#" class="card-title btn" data-bs-toggle="collapse" data-bs-target="#v1-q0">
                                    <i class="fas fa-angle-down angle"></i>
                                    What does the package include?
                                </a>
                            </div>

                            <div id="v1-q0" class="collapse show" data-bs-parent="#faqs-accordion">
                                <div class="card-body">
                                    When you buy Dashcore, you get all you see in the demo but the images. We include SASS files for styling, complete JS files with comments, all HTML variations. Besides we include all mobile PSD mockups.
                                </div>
                            </div>
                        </div>
                        <div class="card mb-3">
                            <div class="card-header">
                                <a href="#" class="card-title btn collapsed" data-bs-toggle="collapse" data-bs-target="#v1-q1">
                                    <i class="fas fa-angle-down angle"></i>
                                    What is the typical response time for a support question?
                                </a>
                            </div>

                            <div id="v1-q1" class="collapse" data-bs-parent="#faqs-accordion">
                                <div class="card-body">
                                    Since you report us a support question we try to make our best to find out what is going on, depending on the case it could take more or les time, however a standard time could be minutes or hours.
                                </div>
                            </div>
                        </div>
                        <div class="card mb-3">
                            <div class="card-header">
                                <a href="#" class="card-title btn collapsed" data-bs-toggle="collapse" data-bs-target="#v1-q2">
                                    <i class="fas fa-angle-down angle"></i>
                                    What do I need to know to customize this template?
                                </a>
                            </div>

                            <div id="v1-q2" class="collapse" data-bs-parent="#faqs-accordion">
                                <div class="card-body">Our documentation give you all you need to customize your copy. However you will need some basic web design knowledge (HTML, Javascript and CSS)</div>
                            </div>
                        </div>
                        <div class="card mb-3">
                            <div class="card-header">
                                <a href="#" class="card-title btn collapsed" data-bs-toggle="collapse" data-bs-target="#v1-q3">
                                    <i class="fas fa-angle-down angle"></i>
                                    Can I suggest a new feature?
                                </a>
                            </div>

                            <div id="v1-q3" class="collapse" data-bs-parent="#faqs-accordion">
                                <div class="card-body">
                                    Definitely &lt;span class=&#039;bold&#039;&gt;Yes&lt;/span&gt;, you can contact us to let us know your needs. If your suggestion represents any value to both we can include it as a part of the theme or
                                    you can request a custom build by an extra cost. Please note it could take some time in order for the feature to be implemented.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ./CTA - Start Now -->
    <section class="section">
        <div class="container bring-to-front">
            <div class="shadow rounded text-center bg-dark p-5">
                <div class="text-contrast">
                    <i class="fa fa-heart fa-2x mb-3"></i>
                    <h2 class="mb-5 text-contrast">Try Dashcore now... Love it forever!</h2>
                    <p class="handwritten highlight font-md">Why wait? Start now!</p>
                </div>

                <a href="register.html" class="btn btn-success text-contrast btn-rounded mt-4">
                    Buy DashCore on Themeforest
                </a>
            </div>
        </div>
    </section>
    <!-- ./CTA - Create Account -->
    <section class="section bg-contrast edge top-left b-b">
        <div class="container pt-5">
            <div class="d-flex align-items-center flex-column flex-md-row">
                <div class="text-center text-md-start">
                    <p class="light mb-0 text-primary lead">Ready to get started?</p>
                    <h2 class="mt-0 bold">Create an account now</h2>
                </div>

                <a href="register.html" class="btn btn-primary btn-rounded mt-3 mt-md-0 ms-md-auto">
                    Create DashCore account
                </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/frontend/pricing.blade.php ENDPATH**/ ?>