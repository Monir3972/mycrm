
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Update Page'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<!-- quill css -->
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Update Page <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-xl-11 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Update Faq <small class="text-success text-sm fw-bold">Frontend</small></h4>
                    <div class="flex-shrink-0">
                        <a href="<?php echo e(route('faqList')); ?>" class="btn btn-info btn-sm">
                            <i class="las la-list align-middle"></i> Faq List
                        </a>
                    </div>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>  
                    <p class="text-muted">Update <code>FAQ</code> using this box</p>
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-tabs-custom nav-success nav-justified mb-3" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#newPage" role="tab" aria-selected="true">
                            <i class="las la-list"></i> Update FAQ
                            </a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <form method="POSt" action="<?php echo e(route('updateFaq')); ?>" class="tab-content text-muted">
                        <div class="tab-pane active row" id="newPage" role="tabpanel">
                            <div class="col-10 mx-auto">
                                <?php if(!empty($faq)): ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="faqId" value="<?php echo e($faq->id); ?>">
                                <div class="mb-3">
                                    <label for="question" class="form-label">Page Title</label>
                                    <input type="text" class="form-control" id="question" placeholder="Enter FAQ question" value="<?php echo e($faq->question); ?>" name="question">
                                </div>
                                <div class="mb-3">
                                    <label for="answer" class="form-label">Answer</label>
                                    <textarea id="answer" name="answer" class="ckeditor-classic"> <?php echo e($faq->answer); ?></textarea>
                                </div>
                                <div class="text-start mt-4 col-10">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                                <?php else: ?>
                                    <div class="alert alert-info">Sorry! No data found</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div> <!-- .card-->
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/listjs.init.js')); ?>"></script>

<!-- ckeditor -->
<script src="<?php echo e(asset('public/assets/libs/@ckeditor/@ckeditor.min.js')); ?>"></script>

<!-- quill js -->
<script src="<?php echo e(asset('public/assets/libs/quill/quill.min.js')); ?>"></script>

<!-- init js -->
<script src="<?php echo e(asset('public/assets/js/pages/form-editor.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/editFaq.blade.php ENDPATH**/ ?>