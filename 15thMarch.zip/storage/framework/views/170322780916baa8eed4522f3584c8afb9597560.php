
<?php $__env->startSection('title'); ?> <?php echo app('translator')->get('Server Default Page'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/')); ?>public/assets/libs/jsvectormap/jsvectormap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/swiper/swiper.min.css" rel="stylesheet" type="text/css" />
<!-- quill css -->
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('/')); ?>public/assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('superadmin.components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?> Dashboards <?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?> Default Page <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-xl-11 mx-auto">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">Default Pages <small class="text-success text-sm fw-bold">Frontend</small></h4>
                </div><!-- end card header -->

                <div class="card-body">
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo Session::get('success'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo Session::get('error'); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>  
                    <p class="text-muted">Create <code>page</code> using this box</p>
                    <?php echo csrf_field(); ?>
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-tabs-custom nav-success nav-justified mb-3" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#newPage" role="tab" aria-selected="true">
                            <i class="las la-file"></i> New Page
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#defaultPage" role="tab" aria-selected="false">
                                <i class="las la-list"></i> Default Pages
                            </a>
                        </li> 
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content text-muted">
                        <div class="tab-pane" id="defaultPage" role="tabpanel">
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <div class="table-responsive mt-3 mb-1">
                                        <table class="table align-middle" id="customerTable">
                                            <thead class="table-light">
                                                <th>Page Name</th>
                                                <th>URL</th>
                                                <th>Action</th>
                                            </thead>
                                            <tbody>
                                                <?php if(count($page)>0): ?>
                                                <?php
                                                    $x=1;
                                                ?>
                                                <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($p->pageName); ?></td>
                                                    <td><input type="text" class="form-control" value="https://www.creativeitpark.com/<?php echo e($p->url); ?>" readonly></td>
                                                    <td>
                                                        <a href="<?php echo e(route('editPage',['id'=>$p->id])); ?>" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                                        <a href="<?php echo e(route('delPage',['id'=>$p->id])); ?>" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                                    </td>
                                                </tr>
                                                <?php
                                                    $x=1;
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <tr>
                                                    <td>Example Page</td>
                                                    <td><input type="text" class="form-control" value="https://www.creativeitpark.com/example-page" readonly></td>
                                                    <td>
                                                        <a href="#" class="btn btn-primary btn-sm"><i class="ri-edit-box-line"></i></a>  
                                                        <a href="#" class="btn btn-danger btn-sm"><i class="ri-delete-bin-6-line"></i></a>    
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('savePage')); ?>" method="POST" class="tab-pane active row" id="newPage" role="tabpanel">
                            <?php echo csrf_field(); ?>
                            <div class="col-10 mx-auto">
                                <div class="mb-3">
                                    <label for="pageName" class="form-label">Page Title</label>
                                    <input type="text" class="form-control" id="pageName" placeholder="Enter page name" name="pageName">
                                </div>
                                <div class="mb-3">
                                    <label for="pageUrl" class="form-label">URL</label>
                                    <div class="input-group">
                                        <div class="input-group-text"><?php echo e(url('/')); ?>/</div>
                                        <input type="text" class="form-control" name="pageUrl" id="pageUrl" placeholder="page-title">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="pageContent" class="form-label">Content</label>
                                    <textarea id="pageContent" name="pageContent" class="ckeditor-classic"></textarea>
                                </div>
                                <div class="mb-3">
                                    <h4>SEO Fields</h4>
                                </div>
                                <div class="mb-3">
                                    <label for="metaTitle" class="form-label">Meta Title</label>
                                    <input type="text" class="form-control" id="metaTitle" placeholder="Enter meta title" name="metaTitle">
                                </div>
                                <div class="mb-3">
                                    <label for="metaDetails" class="form-label">Meta Details</label>
                                    <textarea class="form-control" id="metaDetails" placeholder="Enter meta details" name="metaDetails"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="keyword" class="form-label">Keyword</label>
                                    <textarea class="form-control" id="keyword" placeholder="Enter keyword" name="keyword"></textarea>
                                </div>
                                <div class="text-start mt-4 col-10">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> <!-- .card-->
        </div> <!-- .col-->
        <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- apexcharts -->
<script src="<?php echo e(asset('public/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/libs/swiper/swiper.min.js')); ?>"></script>
<!-- dashboard init -->
<script src="<?php echo e(asset('public/assets/js/pages/dashboard-ecommerce.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/pages/listjs.init.js')); ?>"></script>

<!-- ckeditor -->
<script src="<?php echo e(asset('public/assets/libs/@ckeditor/@ckeditor.min.js')); ?>"></script>

<!-- quill js -->
<script src="<?php echo e(asset('public/assets/libs/quill/quill.min.js')); ?>"></script>

<!-- init js -->
<script src="<?php echo e(asset('public/assets/js/pages/form-editor.init.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cip2015/public_html/mycrm/resources/views/superadmin/defaultPage.blade.php ENDPATH**/ ?>